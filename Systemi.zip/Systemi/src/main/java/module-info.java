module school.systemi {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens models to javafx.base;
    opens school.systemi to javafx.fxml;

    exports models;
    exports school.systemi;
}