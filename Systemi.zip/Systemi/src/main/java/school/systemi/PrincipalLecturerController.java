package school.systemi;

import javafx.collections.FXCollections;
import database.DatabaseConnection;
import models.Module;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.sql.SQLException;
import java.sql.Connection;
import models.Week;

public class PrincipalLecturerController {

    @FXML private ComboBox<Module> moduleComboBox;
    @FXML private TextArea weeklyReportArea;
    @FXML private TextField classField;
    @FXML private TextField moduleField;
    @FXML private TextField challengesField;
    @FXML private TextField recommendationsField;
    @FXML private Button submitButton;
    @FXML private Button fillReportButton;
    @FXML private TextField weekField;
    @FXML private Label outputLabel;

    private Map<Integer, String> moduleReports = new HashMap<>();

    public void initialize() {
        loadModules();
        moduleComboBox.setOnAction(this::onModuleSelected);
    }

    // Load modules from the database and populate ComboBox
    private void loadModules() {
        ObservableList<Module> modules = FXCollections.observableArrayList();

        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM modules")) {

            while (resultSet.next()) {
                int id = resultSet.getInt("moduleID");
                String name = resultSet.getString("moduleName");
                modules.add(new Module(id, name));
            }

            moduleComboBox.setItems(modules);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Submit report for the selected module and save it to the reports table
    @FXML
    private void submitReport(ActionEvent event) {
        Module selectedModule = moduleComboBox.getValue();
        String className = classField.getText();
        String moduleName = selectedModule != null ? selectedModule.getModuleName() : null;
        String challenges = challengesField.getText();
        String recommendations = recommendationsField.getText();

        if (moduleName != null && !className.isEmpty() && !challenges.isEmpty() && !recommendations.isEmpty()) {
            try (Connection connection = DatabaseConnection.getConnection();
                 PreparedStatement statement = connection.prepareStatement(
                         "INSERT INTO reports (Module, Class, Challenges, Recomendation) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE " +
                                 "Class = VALUES(Class), Challenges = VALUES(Challenges), Recomendation = VALUES(Recomendation)")) {

                statement.setString(1, moduleName);
                statement.setString(2, className);
                statement.setString(3, challenges);
                statement.setString(4, recommendations);
                statement.executeUpdate();

                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Report submitted for " + moduleName);
                alert.show();

            } catch (SQLException e) {
                e.printStackTrace();
                Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to submit report.");
                alert.show();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Please fill in all fields and select a module.");
            alert.show();
        }
    }

    // Fill in the weekly report area based on input fields
    @FXML
    private void fillWeeklyReport(ActionEvent event) {
        String report = "Class: " + classField.getText() +
                "\nModule: " + moduleField.getText() +
                "\nChallenges: " + challengesField.getText() +
                "\nRecommendations: " + recommendationsField.getText();
        weeklyReportArea.setText(report);
    }
    @FXML public void logOut() throws Exception{
        Main.showLoginPage();
    }
    // Restrict populating forms with pre-saved data
    private void onModuleSelected(ActionEvent event) {
        Module selectedModule = moduleComboBox.getValue();

        if (selectedModule != null) {
            // Check if a report already exists for this module and class in the database
            try (Connection connection = DatabaseConnection.getConnection();
                 PreparedStatement statement = connection.prepareStatement(
                         "SELECT * FROM reports WHERE Module = ? AND Class = ?")) {

                statement.setString(1, selectedModule.getModuleName());
                statement.setString(2, classField.getText());
                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    Alert alert = new Alert(Alert.AlertType.WARNING, "A report already exists for this module and class.");
                    alert.show();
                    moduleComboBox.getSelectionModel().clearSelection();
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public void setWeekField() {
        String week = weekField.getText().trim();
        if (week.isEmpty()) {
            outputLabel.setText("Academic year cannot be empty.");
            return;
        }
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO weeks (week) VALUES (?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, week);
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                outputLabel.setText("Week added successfully.");
                weekField.clear();
            } else {
                outputLabel.setText("Failed to add Week.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error adding academic year.");
        }
    }
}
