package school.systemi;

// src/controllers/LoginPageController.java

import database.DatabaseConnection;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class LoginPageController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label statusLabel;






    // Login function that checks the user credentials and navigates to the appropriate page
    public void login() {
        String username = usernameField.getText();
        String password = passwordField.getText();
        LocalDateTime timeNow = LocalDateTime.now();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yy HH:mm:ss" );
        String Time = timeNow.format(format);

        if (username.isEmpty() || password.isEmpty()) {
            statusLabel.setText("Please fill in all fields.");
            return;
        }

        try(BufferedWriter writeLog = new BufferedWriter(new FileWriter("C:/Users/refil/Desktop/LOG/user_Logs.txt",true));){
            writeLog.write(username);
            writeLog.newLine();
            writeLog.write(Time);
            writeLog.newLine();
            writeLog.newLine();

        }catch (Exception errorException){
            System.err.println("Could not write to the user_log.txt file...");
            errorException.printStackTrace();
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT role FROM Users WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String role = rs.getString("role");
                statusLabel.setText("Login successful!");

                // Use try-catch to handle potential exceptions when switching scenes
                try {
                    if ("Faculty Admin".equals(role)) {
                        Main.showFacultyAdminPage();
                    }
                    else if ("Lecturer".equals(role)) {
                        Main.showLecturerPage();
                    }
                    else if ("Principal Lecturer".equals(role)) {
                        Main.showPrincipalLecturerView();
                    }
                    else {
                        statusLabel.setText("Unknown role.");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    showErrorAlert("Error loading the page.");
                }
            } else {
                statusLabel.setText("Invalid username or password.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            statusLabel.setText("Database connection error.");
        }
    }

    // Helper method to show an error alert dialog
    private void showErrorAlert(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
