package school.systemi;
import java.sql.*;

public class DatabaseManager {

    public final String url = "jdbc:mysql://localhost:3306/connect";
    public final String user = "root";
    public final String password = "123456";

    public Connection getConn() throws SQLException{
        Connection connection =null;
        try {
            connection = DriverManager.getConnection(url,user,password);
            System.out.println("Success");

        }catch (SQLException e){
            System.err.println("Failed to connect to database");
            e.printStackTrace();
        }

        return connection;
    }







}
