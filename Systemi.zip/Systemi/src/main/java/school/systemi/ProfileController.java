package school.systemi;

import database.DatabaseConnection;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.sql.*;
public class ProfileController {
    @FXML
    private Label profileLabel;
    @FXML private Label outputLabel;

    public void viewProfile() {
        String adminUsername = "Admin"; // Replace with actual logic
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Users WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, adminUsername);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String fullName = rs.getString("Full_Names");
                String role = rs.getString("role");
                profileLabel.setText("Name: " + fullName + ", Role: " + role);
            } else {
                outputLabel.setText("Profile not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error loading profile.");
        }
    }
    @FXML public void back() throws Exception{
        Main.showFacultyAdminPage();
    }

}
