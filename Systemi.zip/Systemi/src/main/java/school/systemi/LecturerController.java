package school.systemi;

import database.DatabaseConnection;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import models.*;
import models.Class;
import models.Module;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import models.Lecturer;
import models.Module;
import models.Assignment;
import models.Class;
import models.Semester;
import models.PasswordUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.PasswordField;


import java.sql.ResultSet;


public class LecturerController {
    @FXML private Label modulesLabel;
    @FXML private Label outputLabel;
    @FXML private Label profileLabel;

    @FXML private TableView<Lecturer> lecturerTable;
    @FXML private TableColumn<Lecturer, String> lecturerNameColumn;

    @FXML private TableView<Module> moduleTable;
    @FXML private TableColumn<Module, String> moduleNameColumn;

    @FXML private TableView<Assignment> assignmentTable;
    @FXML private TableColumn<Assignment, String> assignmentLecturerColumn;
    @FXML private TableColumn<Assignment, String> assignmentModuleColumn;

    @FXML private ComboBox<Lecturer> lecturerComboBox;
    @FXML private ComboBox<Module> moduleComboBox;
    @FXML private ComboBox<Class> classComboBox;
    @FXML private ComboBox<Semester> semesterComboBox;

    @FXML private TextField yearField;
    @FXML private TextField semesterField;
    @FXML private TextField moduleNameField;
    @FXML private TextField lecturerNameField;
    @FXML private PasswordField lecturerPasswordField;

    @FXML public void onStudentTicks() throws Exception {
        Main.showStudentTicksView();
    }
    @FXML public void onChapters() throws Exception {
        Main.showChaptersView();
    }

    @FXML public void logOut() throws Exception{
        Main.showLoginPage();
    }
    public void viewModules() {
        Lecturer selectedLecturer = lecturerComboBox.getValue();
        Module selectedModule = moduleComboBox.getValue();
        Class selectedClass = classComboBox.getValue();
        Semester selectedSemester = semesterComboBox.getValue();


        if (selectedLecturer == null || selectedModule == null || selectedClass == null || selectedSemester == null) {
            outputLabel.setText("Please select a lecturer, module, class, and semester.");
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Check if the lecturer is already assigned to the module in the selected semester and class
            String checkSql = "SELECT * FROM Assignments WHERE lecturer = ? AND module = ? AND class = ? AND semester = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, selectedLecturer.getFullName());
            checkStmt.setString(2, selectedModule.getModuleName());
            checkStmt.setString(3, selectedClass.getName());
            checkStmt.setString(4, selectedSemester.getSemesterName());
            ResultSet checkRs = checkStmt.executeQuery();

            if (checkRs.next()) {
                outputLabel.setText("This lecturer is already assigned to this module in this semester.");
                return;
            }

            // Assign lecturer to module
            String sql = "INSERT INTO Assignments (lecturer, module, class, semester) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, selectedLecturer.getFullName());
            stmt.setString(2, selectedModule.getModuleName());
            stmt.setString(3, selectedClass.getName());
            stmt.setString(4, selectedSemester.getSemesterName());

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                outputLabel.setText("Lecturer assigned to module successfully.");
                 // Refresh the assignments table
            } else {
                outputLabel.setText("Failed to assign lecturer to module.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error assigning lecturer to module.");
        }
    }
}

