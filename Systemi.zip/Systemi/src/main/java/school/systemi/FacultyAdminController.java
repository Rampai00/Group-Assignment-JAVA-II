package school.systemi;


import database.DatabaseConnection;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;

import java.sql.*;

import javafx.scene.control.TextField;

import models.Lecturer;
import models.Module;
import models.Assignment;
import models.Class;
import models.Semester;
import models.PasswordUtils;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.PasswordField;

public class FacultyAdminController {
    @FXML private Label outputLabel;
    @FXML private Label profileLabel;

    @FXML private TableView<Lecturer> lecturerTable;
    @FXML private TableColumn<Lecturer, String> lecturerNameColumn;

    @FXML private TableView<Module> moduleTable;
    @FXML private TableColumn<Module, String> moduleNameColumn;

    @FXML private TableView<Assignment> assignmentTable;
    @FXML private TableColumn<Assignment, String> assignmentLecturerColumn;
    @FXML private TableColumn<Assignment, String> assignmentModuleColumn;

    @FXML private ComboBox<Lecturer> lecturerComboBox;
    @FXML private ComboBox<Module> moduleComboBox;
    @FXML private ComboBox<Class> classComboBox;
    @FXML private ComboBox<Semester> semesterComboBox;

    @FXML private TextField yearField;
    @FXML private TextField semesterField;
    @FXML private TextField moduleNameField;
    @FXML private TextField lecturerNameField;
    @FXML private PasswordField lecturerPasswordField;

    @FXML private TableView<Lecturer0> lecturerTable0;
    @FXML private TableColumn<Lecturer0, String> Lecture0;
    @FXML private TableColumn<Lecturer0, String> Semester0;
    @FXML private TableColumn<Lecturer0, String> Class0;
    @FXML private TableColumn<Lecturer0, String> Module0;


    public void initialize() {
        // Initialize Table Columns
        lecturerNameColumn.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        moduleNameColumn.setCellValueFactory(new PropertyValueFactory<>("moduleName"));
        assignmentLecturerColumn.setCellValueFactory(new PropertyValueFactory<>("lecturerName"));
        assignmentModuleColumn.setCellValueFactory(new PropertyValueFactory<>("moduleName"));
        Lecture0.setCellValueFactory(new PropertyValueFactory<>("Lecture"));
        Semester0.setCellValueFactory(new PropertyValueFactory<>("Semester"));
        Class0.setCellValueFactory(new PropertyValueFactory<>("Class"));
        Module0.setCellValueFactory(new PropertyValueFactory<>("Module"));

        // Load Data
        loadLecturers0();
        loadLecturers();
        loadModules();
        loadAssignments();
        loadClasses();
        loadSemesters();
        viewProfile();
    }

    // View Profile
    public void viewProfile() {
        String adminUsername = "Admin"; // Replace with actual logic
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Users WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, adminUsername);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String fullName = rs.getString("Full_Names");
                String role = rs.getString("role");
                profileLabel.setText("Name: " + fullName + ", Role: " + role);
            } else {
                outputLabel.setText("Profile not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error loading profile.");
        }
    }
    @FXML public void profile() throws Exception{
        Main.showProfileView();
    }

    @FXML public void asAssigned() throws Exception{
        Main.showAssignedView();
    }
    @FXML public void logOut() throws Exception{
        Main.showLoginPage();
    }
    // Load Lecturers
    public void loadLecturers() {
        ObservableList<Lecturer> lecturers = FXCollections.observableArrayList();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Users WHERE role = 'Lecturer'";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int userID = rs.getInt("userID");
                String fullName = rs.getString("Full_Names");
                if (fullName == null || fullName.trim().isEmpty()) {
                    fullName = rs.getString("username"); // Fallback to username if full name is null
                }
                lecturers.add(new Lecturer(userID, fullName));
            }
            lecturerTable.setItems(lecturers);
            lecturerComboBox.setItems(lecturers);
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error loading lecturers.");
        }
    }

    // Load Lecturers
    public void loadLecturers0() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM assignments;";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String Lecture = rs.getString("Lecturer");
                String Module = rs.getString("Module");
                String Class = rs.getString("Class");
                String Semester = rs.getString("Semester");

                Lecturer0 record = new Lecturer0(Lecture, Module, Class, Semester);
                lecturerTable0.getItems().add(record);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error loading lecturers.");
        }
    }

    // Add a new lecturer
    public void addLecturer() {
        String name = lecturerNameField.getText().trim();
        String password = lecturerPasswordField.getText().trim();

        if (name.isEmpty() || password.isEmpty()) {
            outputLabel.setText("Lecturer name and password cannot be empty.");
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO Users (username, role, password) VALUES (?, 'Lecturer', ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, password);
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                outputLabel.setText("Lecturer added successfully.");
                lecturerNameField.clear();
                lecturerPasswordField.clear();
                loadLecturers(); // Refresh list
            } else {
                outputLabel.setText("Failed to add lecturer.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error adding lecturer.");
        }
    }

    // Add a new academic year
    public void addAcademicYear() {
        String year = yearField.getText().trim();
        if (year.isEmpty()) {
            outputLabel.setText("Academic year cannot be empty.");
            return;
        }
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO AcademicYears (year) VALUES (?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, year);
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                outputLabel.setText("Academic year added successfully.");
                yearField.clear();
            } else {
                outputLabel.setText("Failed to add academic year.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error adding academic year.");
        }
    }

    // Add new semester and module
    public void addSemesterAndModule() {
        String semester = semesterField.getText().trim();
        String moduleName = moduleNameField.getText().trim();
        if (semester.isEmpty() || moduleName.isEmpty()) {
            outputLabel.setText("Both semester and module name are required.");
            return;
        }
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);

            String sqlSemester = "INSERT INTO Semesters (semesterName, academicYearID) VALUES (?, ?)";
            String getLatestYearSQL = "SELECT yearID FROM AcademicYears ORDER BY yearID DESC LIMIT 1";
            PreparedStatement getYearStmt = conn.prepareStatement(getLatestYearSQL);
            ResultSet rsYear = getYearStmt.executeQuery();
            if (!rsYear.next()) {
                outputLabel.setText("No academic year found. Please add an academic year first.");
                conn.rollback();
                return;
            }
            int latestYearID = rsYear.getInt("yearID");

            PreparedStatement stmtSemester = conn.prepareStatement(sqlSemester);
            stmtSemester.setString(1, semester);
            stmtSemester.setInt(2, latestYearID);
            stmtSemester.executeUpdate();

            String sqlModule = "INSERT INTO Modules (moduleName) VALUES (?)";
            PreparedStatement stmtModule = conn.prepareStatement(sqlModule);
            stmtModule.setString(1, moduleName);
            stmtModule.executeUpdate();

            conn.commit();
            outputLabel.setText("Semester and module added successfully.");
            semesterField.clear();
            moduleNameField.clear();
            loadModules();
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error adding semester and module.");
        }
    }

    // Load Modules
    public void loadModules() {
        ObservableList<Module> modules = FXCollections.observableArrayList();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Modules";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int moduleID = rs.getInt("moduleID");
                String moduleName = rs.getString("moduleName");
                modules.add(new Module(moduleID, moduleName));
            }
            moduleTable.setItems(modules);
            moduleComboBox.setItems(modules);
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error loading modules.");
        }
    }

    // Load Classes
    public void loadClasses() {
        ObservableList<Class> classes = FXCollections.observableArrayList();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Class";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("ID");
                String name = rs.getString("Name");
                classes.add(new Class(id, name));
            }
            classComboBox.setItems(classes);
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error loading classes.");
        }
    }

    // Load Semesters
    public void loadSemesters() {
        ObservableList<Semester> semesters = FXCollections.observableArrayList();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Semesters";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int semesterID = rs.getInt("semesterID");
                String semesterName = rs.getString("semesterName");
                semesters.add(new Semester(semesterID, semesterName));
            }
            semesterComboBox.setItems(semesters);
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error loading semesters.");
        }
    }

    // Assign Lecturer to Module
    public void assignLecturerToModule() {
        Lecturer selectedLecturer = lecturerComboBox.getValue();
        Module selectedModule = moduleComboBox.getValue();
        Class selectedClass = classComboBox.getValue();
        Semester selectedSemester = semesterComboBox.getValue();

        if (selectedLecturer == null || selectedModule == null || selectedClass == null || selectedSemester == null) {
            outputLabel.setText("Please select a lecturer, module, class, and semester.");
            return;
        }

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Check if the lecturer is already assigned to the module in the selected semester and class
            String checkSql = "SELECT * FROM Assignments WHERE lecturer = ? AND module = ? AND class = ? AND semester = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, selectedLecturer.getFullName());
            checkStmt.setString(2, selectedModule.getModuleName());
            checkStmt.setString(3, selectedClass.getName());
            checkStmt.setString(4, selectedSemester.getSemesterName());
            ResultSet checkRs = checkStmt.executeQuery();

            if (checkRs.next()) {
                outputLabel.setText("This lecturer is already assigned to this module in this semester.");
                return;
            }

            // Assign lecturer to module
            String sql = "INSERT INTO Assignments (lecturer, module, class, semester) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, selectedLecturer.getFullName());
            stmt.setString(2, selectedModule.getModuleName());
            stmt.setString(3, selectedClass.getName());
            stmt.setString(4, selectedSemester.getSemesterName());

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                outputLabel.setText("Lecturer assigned to module successfully.");
                loadAssignments(); // Refresh the assignments table
            } else {
                outputLabel.setText("Failed to assign lecturer to module.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error assigning lecturer to module.");
        }
    }

    // Load Assignments
    public void loadAssignments() {
        ObservableList<Assignment> assignments = FXCollections.observableArrayList();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Assignments";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String lecturerName = rs.getString("lecturer");
                String moduleName = rs.getString("module");
                String className = rs.getString("class");
                String semesterName = rs.getString("semester");
                assignments.add(new Assignment(lecturerName, moduleName, className, semesterName));
            }
            assignmentTable.setItems(assignments);
        } catch (SQLException e) {
            e.printStackTrace();
            outputLabel.setText("Error loading assignments.");
        }
    }



    public static class Lecturer0 {

        public String Lecture0;
        public String Module0;
        public String Class0;
        public String Semester0;

        public Lecturer0(String Lecture0 , String Module0, String Class0, String Semester0){
            this.Lecture0 = Lecture0;
            this.Module0 = Module0;
            this.Class0 = Class0;
            this.Semester0 = Semester0;
        }

        public String getLecture0(){return Lecture0;}
        public String getModule0(){return Module0;};
        public String getClass0(){return Class0;}
        public String getSemester0(){return Semester0;}
    }
}
