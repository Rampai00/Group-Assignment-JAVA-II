
package school.systemi;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import java.sql.*;

public class DatabaseInteraction extends DatabaseManager {
    public final String url = super.url;
    public final String user = super.user;
    public final String password = super.password;

    @FXML private CheckBox absent;

    @FXML private MenuButton menuButtonDefaultValue;
    @FXML private CheckBox present;
    @FXML private TableView<TickRecord> tableViewTicks;
    @FXML private TableColumn<TickRecord, Integer> studentNoColumn;
    @FXML private TableColumn<TickRecord, String> week1Column;
    @FXML private TableColumn<TickRecord, String> week2Column;
    @FXML private TableColumn<TickRecord, String> week3Column;
    @FXML private TableColumn<TickRecord, String> week4Column;
    @FXML private TableColumn<TickRecord, String> week5Column;

    public String week1Value ="*", week2Value ="*", week3Value ="*", week4Value ="*", week5Value="*";
    public int student_id;

    @FXML
    public void initialize() {
        createTable();
        studentNoColumn.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        week1Column.setCellValueFactory(new PropertyValueFactory<>("week1"));
        week2Column.setCellValueFactory(new PropertyValueFactory<>("week2"));
        week3Column.setCellValueFactory(new PropertyValueFactory<>("week3"));
        week4Column.setCellValueFactory(new PropertyValueFactory<>("week4"));
        week5Column.setCellValueFactory(new PropertyValueFactory<>("week5"));
        loadThem();

        tableViewTicks.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                System.out.println("Value from specified column: " + newSelection.getStudentId());
                student_id = newSelection.getStudentId();
            }
        });
    }

@FXML
public void addRowDetails() {

    System.out.println("Updating data for student_id: " + student_id);
    System.out.println("Week values: " + week1Value + ", " + week2Value + ", " + week3Value + ", " + week4Value + ", " + week5Value);

    addRow(week1Value, week2Value, week3Value, week4Value, week5Value);
    loadThem();
    week1Value ="*";
    week2Value ="*";
    week3Value ="*";
    week4Value ="*";
    week5Value ="*";
}

    private void createTable() {
        String query = "CREATE TABLE IF NOT EXISTS tickrecord (" +
                "tick_id INT, " +
                "week1 VARCHAR(5), " +
                "week2 VARCHAR(5), " +
                "week3 VARCHAR(5), " +
                "week4 VARCHAR(5), " +
                "week5 VARCHAR(5), " +
                "student_id INTEGER REFERENCES student(student_id )" +
                ");";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             Statement statement = connection.createStatement()) {
            statement.executeUpdate(query);
            System.out.println("TickRecord table created or already exists.");
        } catch (SQLException e) {
            System.err.println("Failed to create table.");
            e.printStackTrace();
        }
    }
    @FXML public void setWeek1Value() {
        week1Value = absent.isSelected() ? "N" : present.isSelected() ? "Y" : "*";
        menuButtonDefaultValue.setText("week1");
    }

    @FXML public void setWeek2Value() {
        week2Value = absent.isSelected() ? "N" : present.isSelected() ? "Y" : "*";
        menuButtonDefaultValue.setText("week2");
    }

    @FXML public void setWeek3Value() {
        week3Value = absent.isSelected() ? "N" : present.isSelected() ? "Y" : "*";
        menuButtonDefaultValue.setText("week3");
    }

    @FXML public void setWeek4Value() {
        week4Value = absent.isSelected() ? "N" : present.isSelected() ? "Y" : "*";
        menuButtonDefaultValue.setText("week4");
    }

    @FXML public void setWeek5Value() {
        week5Value = absent.isSelected() ? "N" : present.isSelected() ? "Y" : "*";
        menuButtonDefaultValue.setText("week5");
    }

    public void addRow(String week1, String week2, String week3, String week4, String week5) {
        String checkQuery = "SELECT COUNT(*) FROM tickrecord WHERE student_id = ?";
        String updateQuery = "UPDATE tickrecord SET week1 = ?, week2 = ?, week3 = ?, week4 = ?, week5 = ? WHERE student_id = ?";
        String insertQuery = "INSERT INTO tickrecord (week1, week2, week3, week4, week5, student_id) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            // Check if a row for this student_id exists
            try (PreparedStatement checkStmt = connection.prepareStatement(checkQuery)) {
                checkStmt.setInt(1, student_id);
                ResultSet rs = checkStmt.executeQuery();
                rs.next();
                boolean exists = rs.getInt(1) > 0;

                if (exists) {
                    // Update existing row
                    try (PreparedStatement updateStmt = connection.prepareStatement(updateQuery)) {
                        updateStmt.setString(1, week1);
                        updateStmt.setString(2, week2);
                        updateStmt.setString(3, week3);
                        updateStmt.setString(4, week4);
                        updateStmt.setString(5, week5);
                        updateStmt.setInt(6, student_id);
                        updateStmt.executeUpdate();
                        System.out.println("Data records updated successfully.");
                    }
                } else {
                    // Insert new row
                    try (PreparedStatement insertStmt = connection.prepareStatement(insertQuery)) {
                        insertStmt.setString(1, week1);
                        insertStmt.setString(2, week2);
                        insertStmt.setString(3, week3);
                        insertStmt.setString(4, week4);
                        insertStmt.setString(5, week5);
                        insertStmt.setInt(6, student_id);
                        insertStmt.executeUpdate();
                        System.out.println("New record inserted successfully.");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Failed to update or insert data.");
            e.printStackTrace();
        }
    }
    @FXML public void back() throws Exception{
        Main.showLecturerPage();
    }
    public void loadThem() {

        String sql = "SELECT student.student_id, tick_id, week1, week2, week3, week4, week5 " +
                "FROM student LEFT JOIN tickrecord ON student.student_id = tickrecord.student_id " +
                "ORDER BY student.student_id ASC";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {

            tableViewTicks.getItems().clear();

            while (rs.next()) {
                int student_id1 = rs.getInt("student_id");
                String week1 = rs.getString("week1");
                String week2 = rs.getString("week2");
                String week3 = rs.getString("week3");
                String week4 = rs.getString("week4");
                String week5 = rs.getString("week5");

                TickRecord record = new TickRecord(student_id1, week1, week2, week3, week4, week5);
                tableViewTicks.getItems().add(record);

            }

        } catch (SQLException e) {
            System.err.println("Error loading data.");
            e.printStackTrace();
        }
    }

    public static class TickRecord {
        private final int student_id2;
        private final String week1, week2, week3, week4, week5;

        public TickRecord(int student_id0, String week1, String week2, String week3, String week4, String week5) {
            this.student_id2 = student_id0;
            this.week1 = week1;
            this.week2 = week2;
            this.week3 = week3;
            this.week4 = week4;
            this.week5 = week5;
        }

        public int getStudentId() { return student_id2; }
        public String getWeek1() { return week1; }
        public String getWeek2() { return week2; }
        public String getWeek3() { return week3; }
        public String getWeek4() { return week4; }
        public String getWeek5() { return week5; }
    }
}

