/*package school.systemi;

import database.DatabaseConnection;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AssignedController {

    @FXML private TableView<Lecturer0> LecturerTable0;
    @FXML private TableColumn<Lecturer0, String> Lecture0;
    @FXML private TableColumn<Lecturer0, String> Semester0;
    @FXML private TableColumn<Lecturer0, String> Class0;
    @FXML private TableColumn<Lecturer0, String> Module0;

    @FXML public void initialize(){

        Lecture0.setCellValueFactory(new PropertyValueFactory<>("Lecturer"));
        Semester0.setCellValueFactory(new PropertyValueFactory<>("Semester"));
        Class0.setCellValueFactory(new PropertyValueFactory<>("Class"));
        Module0.setCellValueFactory(new PropertyValueFactory<>("Module"));
        loadLecturers0();

    }

    // Load Lecturers
    public void loadLecturers0() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM assignments;";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String Lecture = rs.getString("Lecturer");
                String Module = rs.getString("Module");
                String Class = rs.getString("Class");
                String Semester = rs.getString("Semester");

               Lecturer0 record = new Lecturer0(Lecture, Module, Class, Semester);
                LecturerTable0.getItems().add(record);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.print("Error loading lecturers.");
        }
    }



    public static class Lecturer0 {

        public String Lecture0;
        public String Module0;
        public String Class0;
        public String Semester0;

        public Lecturer0(String Lecture0 , String Module0, String Class0, String Semester0){
            this.Lecture0 = Lecture0;
            this.Module0 = Module0;
            this.Class0 = Class0;
            this.Semester0 = Semester0;
        }

        public String getLecture0(){return Lecture0;}
        public String getModule0(){return Module0;};
        public String getClass0(){return Class0;}
        public String getSemester0(){return Semester0;}
    }

}*/

package school.systemi;

import database.DatabaseConnection;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AssignedController {

    @FXML private TableView<Lecturer0> lecturerTable;
    @FXML private TableColumn<Lecturer0, String> lecturerColumn;
    @FXML private TableColumn<Lecturer0, String> semesterColumn;
    @FXML private TableColumn<Lecturer0, String> classColumn;
    @FXML private TableColumn<Lecturer0, String> moduleColumn;

    @FXML
    public void initialize() {
        lecturerColumn.setCellValueFactory(new PropertyValueFactory<>("lecturer"));
        semesterColumn.setCellValueFactory(new PropertyValueFactory<>("semester"));
        classColumn.setCellValueFactory(new PropertyValueFactory<>("class"));
        moduleColumn.setCellValueFactory(new PropertyValueFactory<>("module"));
        loadLecturers();
    }

    // Load Lecturers
    public void loadLecturers() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM assignments;";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String lecturer = rs.getString("Lecturer");
                String module = rs.getString("Module");
                String className = rs.getString("Class");
                String semester = rs.getString("Semester");

                Lecturer0 record = new Lecturer0(lecturer, module, className, semester);
                lecturerTable.getItems().add(record);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error loading lecturers.");
        }
    }
    @FXML public void back() throws Exception{
        Main.showFacultyAdminPage();
    }
    public static class Lecturer0 {

        private final String lecturer;
        private final String module;
        private final String className;
        private final String semester;

        public Lecturer0(String lecturer, String module, String className, String semester) {
            this.lecturer = lecturer;
            this.module = module;
            this.className = className;
            this.semester = semester;
        }

        public String getLecturer() {
            return lecturer;
        }

        public String getModule() {
            return module;
        }

        public String getClassName() {
            return className;
        }

        public String getSemester() {
            return semester;
        }
    }
}
