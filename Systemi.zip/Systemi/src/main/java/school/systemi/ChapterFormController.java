package school.systemi;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;

public class ChapterFormController extends DatabaseManager {
    public final String url = super.url;
    public final String user = super.user;
    public final String password = super.password;

    @FXML private TextField chapterIdInput;
    @FXML private TextField chapterTitleInput;
    @FXML private TextArea learningOutcomeInput;

    public int valueAt1;
    public String  valueAt2;
    public String valueAt3;
    public int id;

    @FXML public TableView<ChapterRecord> tableViewChapters;
    @FXML private TableColumn<ChapterRecord, Integer> chapterIdColumn;
    @FXML private TableColumn<ChapterRecord, String> chapterTitleColumn;
    @FXML private TableColumn<ChapterRecord, String> learningOutcomeColumn;
    @FXML private TableColumn<ChapterRecord, Integer> IdColumn;

    @FXML
    public void initialize() {
        createTable();
        chapterIdColumn.setCellValueFactory(new PropertyValueFactory<>("chapterId"));
        chapterTitleColumn.setCellValueFactory(new PropertyValueFactory<>("chapterTitle"));
        learningOutcomeColumn.setCellValueFactory(new PropertyValueFactory<>("learningOutcome"));
        IdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        loadThem();

        // Listener to get selected row data
        tableViewChapters.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                System.out.println("Value from specified column: " + newSelection.getId());
                id = newSelection.getId();
            }
        });
    }

    @FXML
    public void addRowDetails() {
        setValueAt1();
        setValueAt2();
        setValueAt3();
        addRow(valueAt1, valueAt2, valueAt3);
        loadThem();
        chapterIdInput.clear();
        chapterTitleInput.clear();
        learningOutcomeInput.clear();
        andClearValues();
    }

public void andClearValues(){
        valueAt1 = 0;
        valueAt2 = null;
        valueAt3 = null;
}
    public void setValueAt1(){
        valueAt1 = Integer.parseInt(chapterIdInput.getText());
    }
    public void setValueAt2(){
        valueAt2 = chapterTitleInput.getText();
    }
    public void setValueAt3(){
        valueAt3 = learningOutcomeInput.getText();
    }

    private void createTable() {
        String query = "CREATE TABLE IF NOT EXISTS chapters (" +
                "chapter_id INT, " +
                "chapter_title VARCHAR(255), " +
                "learning_outcome TEXT, " +
                "id INTEGER REFERENCES class(id)" +
                ");";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             Statement statement = connection.createStatement()) {

            statement.executeUpdate(query);
            System.out.println("Chapters table created or already exists.");
        } catch (SQLException e) {
            System.err.println("Failed to create table.");
            e.printStackTrace();
        }
    }


        public void addRow(int chapter_id, String chapter_title, String learning_outcome) {
        String checkQuery = "SELECT COUNT(*) FROM chapters WHERE id = ?";
        String updateQuery = "UPDATE chapters SET chapter_id = ?, chapter_title = ?, learning_outcome = ? WHERE id = ?";
        String insertQuery = "INSERT INTO chapters (chapter_id, chapter_title, learning_outcome, id) VALUES (?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            // Check if a row for this id exists
            try (PreparedStatement checkStmt = connection.prepareStatement(checkQuery)) {
                checkStmt.setInt(1, id);
                ResultSet rs = checkStmt.executeQuery();
                rs.next();
                boolean exists = rs.getInt(1) > 0;

                if (exists) {
                    // Update existing row
                    try (PreparedStatement updateStmt = connection.prepareStatement(updateQuery)) {
                updateStmt.setInt(1, chapter_id);  // Chapter ID
                updateStmt.setString(2, chapter_title);  // Chapter Title
                updateStmt.setString(3, learning_outcome);  // Learning Outcome
                updateStmt.setInt(4, id);  // Class ID as Integer
                        updateStmt.executeUpdate();
                        System.out.println("Data records updated successfully.");
                    }
                } else {
                    // Insert new row
                    try (PreparedStatement insertStmt = connection.prepareStatement(insertQuery)) {
                        insertStmt.setInt(1, chapter_id);  // Chapter ID
                        insertStmt.setString(2, chapter_title);  // Chapter Title
                        insertStmt.setString(3, learning_outcome);  // Learning Outcome
                        insertStmt.setInt(4, id);  // Class ID as Integer
                        insertStmt.executeUpdate();
                        System.out.println("New record inserted successfully.");
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Failed to update or insert data.");
            e.printStackTrace();
        }
    }

    @FXML public void back() throws Exception{
        Main.showLecturerPage();
    }

    public void loadThem() {
        try (Connection connection = DriverManager.getConnection(url, user, password);
             Statement statement = connection.createStatement()) {

            String sql = "SELECT class.id, chapter_id, chapter_title, learning_outcome " +
                    "FROM class LEFT JOIN chapters ON class.id = chapters.id ORDER BY class.id ASC;";
            ResultSet rs = statement.executeQuery(sql);

            tableViewChapters.getItems().clear();

            // Populate the TableView with records
            while (rs.next()) {
                int chapterId = rs.getInt("chapter_id");
                String chapterTitle = rs.getString("chapter_title");
                String learningOutcome = rs.getString("learning_outcome");
                int id = rs.getInt("id");

                ChapterRecord record = new ChapterRecord(id, chapterId, chapterTitle, learningOutcome);

                tableViewChapters.getItems().add(record);
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error loading data.");
        }
    }

    public static class ChapterRecord {
        private final int chapterId;
        private final String chapterTitle;
        private final String learningOutcome;
        private final int id;

        public ChapterRecord(int id, int chapterId, String chapterTitle, String learningOutcome) {
            this.chapterId = chapterId;
            this.chapterTitle = chapterTitle;
            this.learningOutcome = learningOutcome;
            this.id = id;
        }

        public int getChapterId() { return chapterId; }
        public String getChapterTitle() { return chapterTitle; }
        public String getLearningOutcome() { return learningOutcome; }
        public int getId() { return id; }
    }
}
