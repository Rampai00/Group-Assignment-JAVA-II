package school.systemi;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Main extends Application {
    private static Stage primaryStage;


    @Override
    public void start(Stage primaryStage) throws Exception {

        Main.primaryStage = primaryStage;
        primaryStage.setTitle("Limkokwing Academic Reporting System");
        showLoginPage();
    }

    public static void showLoginPage() throws Exception {


        FXMLLoader loader = new FXMLLoader(Main.class.getResource("LoginPage.fxml"));
        primaryStage.setScene(new Scene(loader.load()));
        primaryStage.show();
    }

    public static void showFacultyAdminPage() throws Exception {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("FacultyAdminPage.fxml"));
        primaryStage.setScene(new Scene(loader.load()));
    }

    public static void showLecturerPage() throws Exception {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("LecturerPage.fxml"));
        primaryStage.setScene(new Scene(loader.load()));
    }
    public static void showPrincipalLecturerView() throws Exception {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("PrincipalLecturerView.fxml"));
        primaryStage.setScene(new Scene(loader.load()));
    }
    public static void showStudentTicksView() throws Exception {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("tickTable.fxml"));
        primaryStage.setScene(new Scene(loader.load()));
    }
    public static void showChaptersView() throws Exception {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("chapters.fxml"));
        primaryStage.setScene(new Scene(loader.load()));
    }

    public static void showAssignedView() throws Exception {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("AssingedView.fxml"));
        primaryStage.setScene(new Scene(loader.load()));
    }
    public static void showProfileView() throws Exception {
        FXMLLoader loader = new FXMLLoader(Main.class.getResource("ProfileView.fxml"));
        primaryStage.setScene(new Scene(loader.load()));
    }

    public static void main(String[] args) {
        launch(args);
    }
}
