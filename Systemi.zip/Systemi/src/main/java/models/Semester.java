package models;

public class Semester {
    private int semesterID;
    private String semesterName;

    public Semester(int semesterID, String semesterName) {
        this.semesterID = semesterID;
        this.semesterName = semesterName;
    }

    public int getSemesterID() {
        return semesterID;
    }

    public String getSemesterName() {
        return semesterName;
    }

    @Override
    public String toString() {
        return semesterName;
    }
}

