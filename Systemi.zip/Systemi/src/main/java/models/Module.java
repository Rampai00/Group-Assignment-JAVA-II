package models;

public class Module {
    private int moduleID;
    private String moduleName;

    public Module(int moduleID, String moduleName) {
        this.moduleID = moduleID;
        this.moduleName = moduleName;
    }

    public int getModuleID() {
        return moduleID;
    }

    public String getModuleName() {
        return moduleName;
    }

    @Override
    public String toString() {
        return moduleName;
    }
}

