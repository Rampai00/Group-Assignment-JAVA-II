package models;

public class Week {
    private int ID;
    private String week;

    public Week(int ID, String week) {
        this.ID = ID;
        this.week = week;
    }

    public int getID() {
        return ID;
    }

    public String getWeek() {
        return week;
    }

    @Override
    public String toString() {
        return week;
    }
}
