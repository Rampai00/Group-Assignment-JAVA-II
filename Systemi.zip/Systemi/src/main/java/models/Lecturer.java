package models;

public class Lecturer {
    private int userID;
    private String fullName;


    public Lecturer(int userID, String fullName) {
        this.userID = userID;
        this.fullName = fullName;
    }

    public int getUserID() {
        return userID;
    }

    public String getFullName() {
        return fullName;
    }

    @Override
    public String toString() {
        return fullName;
    }
}



