package models;

public class Class {
    private int classID;
    private String className;

    public Class(int classID, String className) {
        this.classID = classID;
        this.className = className;
    }

    public int getId() {
        return classID;
    }

    public String getName() {
        return className;
    }

    @Override
    public String toString() {
        return className;
    }
}

