package models;

public class Assignment {
    private String lecturerName;
    private String moduleName;
    private String className;
    private String semesterName;

    public Assignment(String lecturerName, String moduleName, String className, String semesterName) {
        this.lecturerName = lecturerName;
        this.moduleName = moduleName;
        this.className = className;
        this.semesterName = semesterName;
    }

    public String getLecturerName() {
        return lecturerName;
    }

    public String getModuleName() {
        return moduleName;
    }

    public String getClassName() {
        return className;
    }

    public String getSemesterName() {
        return semesterName;
    }
}


